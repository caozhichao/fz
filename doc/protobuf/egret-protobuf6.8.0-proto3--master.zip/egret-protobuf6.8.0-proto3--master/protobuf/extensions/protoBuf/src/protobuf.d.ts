/*!
 * protobuf.js 3.2.0
 * disunit
 * 2017/05/19
 */
declare var protobuf:any;