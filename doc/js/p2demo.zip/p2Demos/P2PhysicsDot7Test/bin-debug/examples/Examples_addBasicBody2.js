/**
 * 这里测试jbp2里面封装的工具
 */
var Examples_addBasicBody2 = (function (_super) {
    __extends(Examples_addBasicBody2, _super);
    function Examples_addBasicBody2() {
        _super.call(this);
        //物理世界转换系数
        this.factor = 50;
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdded2stage, this);
    }
    var d = __define,c=Examples_addBasicBody2,p=c.prototype;
    p.onAdded2stage = function (e) {
        this.createGameScene();
    };
    /**
    * 创建游戏场景
    */
    p.createGameScene = function () {
        jbP2.P2Space.initSpace(this.factor, new egret.Rectangle(0, 0, this.stage.stageWidth, this.stage.stageHeight));
        //创建world
        this.world = new p2.World();
        this.world.sleepMode = p2.World.BODY_SLEEPING;
        //创建plane
        var planeShape = new p2.Plane();
        var planeBody = new p2.Body();
        planeBody.type = p2.Body.STATIC;
        planeBody.addShape(planeShape);
        planeBody.displays = [];
        this.world.addBody(planeBody);
        egret.Ticker.getInstance().register(this.p2RunStep, this);
        jbP2.P2Space.addOneBox(this.world, this, 400, 300, 800, 25, 0, p2.Body.STATIC); //ground
        jbP2.P2Space.addOneBox(this.world, this, 0, 240, 10, 480, 0, p2.Body.STATIC); //left wall
        jbP2.P2Space.addOneBox(this.world, this, 800, 240, 10, 480, 0, p2.Body.STATIC); //right wall
        jbP2.P2Space.addOneBox(this.world, this, 400, 400, 250, 5, 10, p2.Body.STATIC); //middle static
        jbP2.P2Space.addOneBox(this.world, this, 400, 100, 200, 50, 10, p2.Body.DYNAMIC); //box1
        jbP2.P2Space.addOneBall(this.world, this, 400, 50, 40, 0, p2.Body.DYNAMIC); //ball1
        jbP2.P2Space.addOneBall(this.world, this, 100, 100, 30, 0, p2.Body.DYNAMIC); //ball1
    };
    /**
    * p2 physics run step
    */
    p.p2RunStep = function (dt) {
        if (dt < 10) {
            return;
        }
        if (dt > 1000) {
            return;
        }
        this.world.step(dt / 1000); //p2.World.step
        //更新p2World内所有刚体皮肤显示
        jbP2.P2Space.updateWorldBodiesSkin(this.world);
    };
    return Examples_addBasicBody2;
})(egret.DisplayObjectContainer);
egret.registerClass(Examples_addBasicBody2,'Examples_addBasicBody2');
//# sourceMappingURL=Examples_addBasicBody2.js.map