/**
 * fixed X and fixed Y
 * @author
 *
 */
var Examples_fixedXY = (function (_super) {
    __extends(Examples_fixedXY, _super);
    function Examples_fixedXY() {
        _super.call(this);
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdded2stage, this);
    }
    var d = __define,c=Examples_fixedXY,p=c.prototype;
    p.onAdded2stage = function (e) {
        this.scene = new jbP2.SimpleP2Scene(this.stage, this);
        this.scene.world.sleepMode = p2.World.NO_SLEEPING;
        //鼠标拾取工具实例
        var mouseJt = new P2MouseJointHelper(this.stage, this, this.scene.world);
        var tembody;
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 0, 240, 10, 480, 0, p2.Body.STATIC); //left wall
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 800, 240, 10, 480, 0, p2.Body.STATIC); //right wall                 
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 400, 400, 800, 20, 0, p2.Body.STATIC); //middle static
        var fixedX = jbP2.P2Space.addOneBall(this.scene.world, this.scene.dispCtn, 250, 50, 40, 0, p2.Body.DYNAMIC); //ball
        fixedX.fixedX = true;
        var fixedY = jbP2.P2Space.addOneBall(this.scene.world, this.scene.dispCtn, 100, 100, 30, 0, p2.Body.DYNAMIC); //ball
        fixedY.fixedY = true;
    };
    return Examples_fixedXY;
})(egret.Sprite);
egret.registerClass(Examples_fixedXY,'Examples_fixedXY');
//# sourceMappingURL=Examples_fixedXY.js.map