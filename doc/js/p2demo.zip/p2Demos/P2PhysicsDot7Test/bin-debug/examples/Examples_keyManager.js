/**
 * 测试键盘控制
 * @author
 *
 */
var Examples_keyManager = (function (_super) {
    __extends(Examples_keyManager, _super);
    function Examples_keyManager() {
        _super.call(this);
        this.wheelAnglarForceDefault = 15; //轮子转动默认角力
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdded2stage, this);
    }
    var d = __define,c=Examples_keyManager,p=c.prototype;
    p.onAdded2stage = function (e) {
        this.scene = new jbP2.SimpleP2Scene(this.stage, this);
        //给予默认摩擦力较大值，防止轮子滑动
        this.scene.world.defaultContactMaterial.friction = 10;
        this.scene.world.defaultContactMaterial.restitution = 0.4;
        //鼠标拾取工具实例
        this.mouseJt = new MouseJointHelper(this.stage, this, this.scene.world);
        jbP2.KeyManager.init();
        var tembody;
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 0, 240, 50, 480, 0, p2.Body.STATIC); //left wall
        tembody.id = 0;
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 800, 240, 50, 480, 0, p2.Body.STATIC); //right wall
        tembody.id = 1;
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 400, 400, 800, 20, 0, p2.Body.STATIC); //middle static
        tembody.id = 2;
        tembody = jbP2.P2Space.addOneBall(this.scene.world, this.scene.dispCtn, 100, 100, 30, 0, p2.Body.DYNAMIC); //ball1
        tembody.id = 5;
        this.wheel = tembody;
        this.wheel.allowSleep = false;
        egret.Ticker.getInstance().register(this.updateKeyCtrl, this); //
    };
    p.updateKeyCtrl = function () {
        if (jbP2.KeyManager.isDown(jbP2.KeyManager.LEFT)) {
            this.wheel.angularForce = this.wheelAnglarForceDefault;
        }
        else if (jbP2.KeyManager.isDown(jbP2.KeyManager.RIGHT)) {
            this.wheel.angularForce = -this.wheelAnglarForceDefault;
        }
    };
    return Examples_keyManager;
})(egret.Sprite);
egret.registerClass(Examples_keyManager,'Examples_keyManager');
//# sourceMappingURL=Examples_keyManager.js.map