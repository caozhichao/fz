/**
 * ForceField测试
 * @author
 *
 */
var Examples_forceField = (function (_super) {
    __extends(Examples_forceField, _super);
    function Examples_forceField() {
        _super.call(this);
        this.wheelAnglarForceDefault = 15;
        this.forceOn = false;
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdded2stage, this);
    }
    var d = __define,c=Examples_forceField,p=c.prototype;
    p.onAdded2stage = function (e) {
        this.scene = new jbP2.SimpleP2Scene(this.stage, this);
        this.scene.world.defaultContactMaterial.friction = 10;
        //var mouseJt = new P2MouseJointHelper(this.stage,this.scene.dispCtn,this.scene.world,false);
        jbP2.KeyManager.init();
        this.setupScene3();
        this.addEventListener(egret.Event.ENTER_FRAME, this.onEff, this);
    };
    p.onEff = function (e) {
        this.updateKeyCtrl();
        if (this.forceOn) {
            this.wheel.applyForce([20, 0], [0, 0]);
        }
    };
    p.setupScene3 = function () {
        this.wheelMtl = new p2.Material(1000);
        this.groundMtl = new p2.Material(1001);
        this.iceMtl = new p2.Material(1002);
        this.wheel = jbP2.P2Space.addOneBall(this.scene.world, this.scene.dispCtn, 400, 100, 25, 0, p2.Body.DYNAMIC); //box1
        this.wheel.shapes[0].material = this.wheelMtl;
        this.wheel.allowSleep = false;
        jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 0, 240, 10, 480, 0, p2.Body.STATIC); //left wall
        jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 800, 240, 10, 480, 0, p2.Body.STATIC); //right wall
        this.bottomGround = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 400, 400, 800, 20, 0, p2.Body.STATIC); //bottom wall
        this.bottomGround.shapes[0].material = this.groundMtl;
        this.forceField = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 300, 300, 200, 50, 0, p2.Body.KINEMATIC); //
        this.forceField.shapes[0].sensor = true; //注意如果为sensor，则刚体类型需为kinematic或者dynamic
        var cmtlToGround = new p2.ContactMaterial(this.wheelMtl, this.groundMtl, { restitution: 0.0, friction: 10 });
        this.scene.world.addContactMaterial(cmtlToGround);
        var ice = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 400, 375, 150, 20, -18, p2.Body.STATIC); //ice
        ice.shapes[0].material = this.iceMtl;
        var cmtlToIce = new p2.ContactMaterial(this.wheelMtl, this.iceMtl, { restitution: 0.0, friction: 0.1 });
        this.scene.world.addContactMaterial(cmtlToIce);
        this.scene.world.on("beginContact", this.onBeginContact, this); //
        this.scene.world.on("endContact", this.onEndContact, this); //
    };
    p.onBeginContact = function (event) {
        var bodyA = event.bodyA;
        var bodyB = event.bodyB;
        if (bodyA.id == this.forceField.id || bodyB.id == this.forceField.id) {
            console.log("on forceField sensor onBeginContact bodyA.id:" + bodyA.id + ",bodyB.id:" + bodyB.id);
            this.forceOn = true;
        }
    };
    p.onEndContact = function (event) {
        var bodyA = event.bodyA;
        var bodyB = event.bodyB;
        if (bodyA.id == this.forceField.id || bodyB.id == this.forceField.id) {
            console.log("on forceField sensor EndContact bodyA.id:" + bodyA.id + ",bodyB.id:" + bodyB.id);
            this.forceOn = false;
        }
    };
    p.updateKeyCtrl = function () {
        if (jbP2.KeyManager.isDown(jbP2.KeyManager.LEFT)) {
            this.wheel.angularForce = this.wheelAnglarForceDefault;
        }
        else if (jbP2.KeyManager.isDown(jbP2.KeyManager.RIGHT)) {
            this.wheel.angularForce = -this.wheelAnglarForceDefault;
        }
        if (jbP2.KeyManager.isDown(jbP2.KeyManager.UP) && jbP2.P2Space.checkIfCanJump(this.scene.world, this.wheel)) {
            this.wheel.applyForce([0, 400], [0, 0]);
        }
    };
    return Examples_forceField;
})(egret.Sprite);
egret.registerClass(Examples_forceField,'Examples_forceField');
//# sourceMappingURL=Examples_forceField.js.map