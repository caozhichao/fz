/**
 * 胶囊体案例
 * @author
 *
 */
var Examples_capsule = (function (_super) {
    __extends(Examples_capsule, _super);
    function Examples_capsule() {
        _super.call(this);
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdded2stage, this);
    }
    var d = __define,c=Examples_capsule,p=c.prototype;
    p.onAdded2stage = function (e) {
        this.objsCtn = new egret.Sprite();
        this.addChild(this.objsCtn);
        this.drawCtn = new egret.Sprite();
        this.addChild(this.drawCtn);
        this.scene = new jbP2.SimpleP2Scene(this.stage, this.objsCtn);
        this.scene.world.sleepMode = p2.World.NO_SLEEPING;
        //鼠标拾取工具实例
        var mouseJt = new P2MouseJointHelper(this.stage, this.objsCtn, this.scene.world);
        var tembody;
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 0, 240, 10, 480, 0, p2.Body.STATIC); //left wall
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 800, 240, 10, 480, 0, p2.Body.STATIC); //right wall                 
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 400, 400, 800, 20, 0, p2.Body.STATIC); //middle static
        tembody = jbP2.P2Space.addOneBox(this.scene.world, this.scene.dispCtn, 50, 100, 50, 50, 10, p2.Body.DYNAMIC); //box1
        tembody = jbP2.P2Space.addOneCapsule(this.scene.world, this.scene.dispCtn, 400, 100, 50, 20, 10, p2.Body.DYNAMIC); //capsule
    };
    return Examples_capsule;
})(egret.Sprite);
egret.registerClass(Examples_capsule,'Examples_capsule');
//# sourceMappingURL=Examples_capsule.js.map